declare namespace Cypress {
  interface Chainable {

    /**
     * @example cy.login()
     */
    login(): void

  }
}